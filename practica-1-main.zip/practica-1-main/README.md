# Polar Home 🏠
Nuestra página web orientada a la venta de productos y accesorios para el hogar.
## Estado del proyecto
En estos momentos la realización de esta página esta terminada cuando nos referimos a la parte visual, pero aún le queda la parte más importante que es la funcional.
![Preview de la página](/preview/preview.png)
